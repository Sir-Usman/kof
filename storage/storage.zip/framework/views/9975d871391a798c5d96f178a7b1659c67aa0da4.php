<?php $__env->startSection('title', \App\CPU\translate('add_new_seller')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid main-card <?php echo e(Session::get('direction')); ?>">

    <!-- Page Title -->
    <div class="mb-4">
        <h2 class="h1 mb-0 text-capitalize d-flex align-items-center gap-2">
            <img src="<?php echo e(asset('/public/assets/back-end/img/add-new-seller.png')); ?>" class="mb-1" alt="">
            <?php echo e(\App\CPU\translate('add_new_seller')); ?>

        </h2>
    </div>
    <!-- End Page Title -->

    <form class="user" action="<?php echo e(route('shop.apply')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-body">
                <input type="hidden" name="status" value="approved">
                <h5 class="mb-0 text-capitalize d-flex align-items-center gap-2 border-bottom pb-3 mb-4 pl-4">
                    <img src="<?php echo e(asset('/public/assets/back-end/img/seller-information.png')); ?>" class="mb-1" alt="">
                    <?php echo e(\App\CPU\translate('seller_information')); ?>

                </h5>
                <div class="row align-items-center">
                    <div class="col-lg-6 mb-4 mb-lg-0">
                        <div class="form-group">
                            <label for="exampleFirstName" class="title-color d-flex gap-1 align-items-center"><?php echo e(\App\CPU\translate('first_name')); ?></label>
                            <input type="text" class="form-control form-control-user" id="exampleFirstName" name="f_name" value="<?php echo e(old('f_name')); ?>" placeholder="<?php echo e(\App\CPU\translate('Ex: Jhone')); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleLastName" class="title-color d-flex gap-1 align-items-center"><?php echo e(\App\CPU\translate('last_name')); ?></label>
                            <input type="text" class="form-control form-control-user" id="exampleLastName" name="l_name" value="<?php echo e(old('l_name')); ?>" placeholder="<?php echo e(\App\CPU\translate('Ex: Doe')); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPhone" class="title-color d-flex gap-1 align-items-center"><?php echo e(\App\CPU\translate('phone')); ?></label>
                            <input type="number" class="form-control form-control-user" id="exampleInputPhone" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="<?php echo e(\App\CPU\translate('Ex: +09587498')); ?>" required>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <center>
                                <img class="upload-img-view" id="viewer"
                                    src="<?php echo e(asset('public\assets\back-end\img\400x400\img2.jpg')); ?>" alt="banner image"/>
                            </center>
                        </div>

                        <div class="form-group">
                            <div class="title-color mb-2 d-flex gap-1 align-items-center">Seller Image <span class="text-info">(Ratio 1:1)</span></div>
                            <div class="custom-file text-left">
                                <input type="file" name="image" id="customFileUpload" class="custom-file-input"
                                    accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                <label class="custom-file-label" for="customFileUpload"><?php echo e(\App\CPU\translate('Upload')); ?> <?php echo e(\App\CPU\translate('image')); ?></label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-body">
                <input type="hidden" name="status" value="approved">
                <h5 class="mb-0 text-capitalize d-flex align-items-center gap-2 border-bottom pb-3 mb-4 pl-4">
                    <img src="<?php echo e(asset('/public/assets/back-end/img/seller-information.png')); ?>" class="mb-1" alt="">
                    <?php echo e(\App\CPU\translate('account_information')); ?>

                </h5>
                <div class="row">
                    <div class="col-lg-4 form-group">
                        <label for="exampleInputEmail" class="title-color d-flex gap-1 align-items-center"><?php echo e(\App\CPU\translate('email')); ?></label>
                        <input type="email" class="form-control form-control-user" id="exampleInputEmail" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(\App\CPU\translate('Ex: Jhone@company.com')); ?>" required>
                    </div>
                    <div class="col-lg-4 form-group">
                        <label for="exampleInputPassword" class="title-color d-flex gap-1 align-items-center"><?php echo e(\App\CPU\translate('password')); ?></label>
                        <input type="password" class="form-control form-control-user" minlength="8" id="exampleInputPassword" name="password" placeholder="<?php echo e(\App\CPU\translate('Ex: 8+ Character')); ?>" required>
                    </div>
                    <div class="col-lg-4 form-group">
                        <label for="exampleRepeatPassword" class="title-color d-flex gap-1 align-items-center"><?php echo e(\App\CPU\translate('confirm_password')); ?></label>
                        <input type="password" class="form-control form-control-user" minlength="8" id="exampleRepeatPassword" placeholder="<?php echo e(\App\CPU\translate('Ex: 8+ Character')); ?>" required>
                        <div class="pass invalid-feedback"><?php echo e(\App\CPU\translate('Repeat')); ?>  <?php echo e(\App\CPU\translate('password')); ?> <?php echo e(\App\CPU\translate('not match')); ?> .</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-body">
                <h5 class="mb-0 text-capitalize d-flex align-items-center gap-2 border-bottom pb-3 mb-4 pl-4">
                    <img src="<?php echo e(asset('/public/assets/back-end/img/seller-information.png')); ?>" class="mb-1" alt="">
                    <?php echo e(\App\CPU\translate('shop_information')); ?>

                </h5>

                <div class="row">
                    <div class="col-lg-6 form-group">
                        <label for="shop_name" class="title-color d-flex gap-1 align-items-center"><?php echo e(\App\CPU\translate('shop_name')); ?></label>
                        <input type="text" class="form-control form-control-user" id="shop_name" name="shop_name" placeholder="<?php echo e(\App\CPU\translate('Ex: Jhone')); ?>" value="<?php echo e(old('shop_name')); ?>"required>
                    </div>
                    <div class="col-lg-6 form-group">
                        <label for="shop_address" class="title-color d-flex gap-1 align-items-center"><?php echo e(\App\CPU\translate('shop_address')); ?></label>
                        <textarea name="shop_address" class="form-control" id="shop_address"rows="1" placeholder="<?php echo e(\App\CPU\translate('Ex: Doe')); ?>"><?php echo e(old('shop_address')); ?></textarea>
                    </div>
                    <div class="col-lg-6 form-group">
                        <center>
                            <img class="upload-img-view" id="viewerLogo"
                                src="<?php echo e(asset('public\assets\back-end\img\400x400\img2.jpg')); ?>" alt="banner image"/>
                        </center>

                        <div class="mt-4">
                            <div class="d-flex gap-1 align-items-center title-color mb-2">
                                <?php echo e(\App\CPU\translate('shop_logo')); ?>

                                <span class="text-info">(Ratio 1 :1)</span>
                            </div>

                            <div class="custom-file">
                                <input type="file" name="logo" id="LogoUpload" class="custom-file-input"
                                    accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                <label class="custom-file-label" for="LogoUpload"><?php echo e(\App\CPU\translate('Upload')); ?> <?php echo e(\App\CPU\translate('logo')); ?></label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 form-group">
                        <center>
                            <img class="upload-img-view upload-img-view__banner" id="viewerBanner"
                                    src="<?php echo e(asset('public\assets\back-end\img\400x400\img2.jpg')); ?>" alt="banner image"/>
                        </center>

                        <div class="mt-4">
                            <div class="d-flex gap-1 align-items-center title-color mb-2">
                                <?php echo e(\App\CPU\translate('shop_banner')); ?>

                                <span class="text-info">(Ratio 3:1)</span>
                            </div>

                            <div class="custom-file">
                                <input type="file" name="banner" id="BannerUpload" class="custom-file-input"
                                        accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                <label class="custom-file-label" for="BannerUpload"><?php echo e(\App\CPU\translate('Upload')); ?> <?php echo e(\App\CPU\translate('Banner')); ?></label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex align-items-center justify-content-end gap-10">
                    <button type="reset" onclick="resetBtn()" class="btn btn-secondary"><?php echo e(\App\CPU\translate('reset')); ?> </button>
                    <button type="submit" class="btn btn--primary btn-user" id="apply"><?php echo e(\App\CPU\translate('submit')); ?></button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>


<script>
    function resetBtn(){
        let placeholderImg = $("#placeholderImg").data('img');
        $('#viewer').attr('src', placeholderImg);
        $('#viewerBanner').attr('src', placeholderImg);
        $('#viewerLogo').attr('src', placeholderImg);
        $('.spartan_remove_row').click();
    }

    function openInfoWeb()
    {
        var x = document.getElementById("website_info");
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }
</script>
<?php $__env->startPush('script'); ?>
<?php if($errors->any()): ?>
    <script>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        toastr.error('<?php echo e($error); ?>', Error, {
            CloseButton: true,
            ProgressBar: true
        });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
<?php endif; ?>
<script>
    $('#inputCheckd').change(function () {
            // console.log('jell');
            if ($(this).is(':checked')) {
                $('#apply').removeAttr('disabled');
            } else {
                $('#apply').attr('disabled', 'disabled');
            }

        });

    $('#exampleInputPassword ,#exampleRepeatPassword').on('keyup',function () {
        var pass = $("#exampleInputPassword").val();
        var passRepeat = $("#exampleRepeatPassword").val();
        if (pass==passRepeat){
            $('.pass').hide();
        }
        else{
            $('.pass').show();
        }
    });
    $('#apply').on('click',function () {

        var image = $("#image-set").val();
        if (image=="")
        {
            $('.image').show();
            return false;
        }
        var pass = $("#exampleInputPassword").val();
        var passRepeat = $("#exampleRepeatPassword").val();
        if (pass!=passRepeat){
            $('.pass').show();
            return false;
        }


    });
    function Validate(file) {
        var x;
        var le = file.length;
        var poin = file.lastIndexOf(".");
        var accu1 = file.substring(poin, le);
        var accu = accu1.toLowerCase();
        if ((accu != '.png') && (accu != '.jpg') && (accu != '.jpeg')) {
            x = 1;
            return x;
        } else {
            x = 0;
            return x;
        }
    }

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#viewer').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#customFileUpload").change(function () {
        readURL(this);
    });

    function readlogoURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#viewerLogo').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    function readBannerURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#viewerBanner').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#LogoUpload").change(function () {
        readlogoURL(this);
    });
    $("#BannerUpload").change(function () {
        readBannerURL(this);
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.back-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u690825212/domains/khareedofarokht.pk/public_html/resources/views/admin-views/seller/add-new-seller.blade.php ENDPATH**/ ?>