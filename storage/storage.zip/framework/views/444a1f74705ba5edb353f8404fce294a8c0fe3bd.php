<?php $__env->startSection('title', \App\CPU\translate('Privacy policy')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Title -->
        <div class="mb-3">
            <h2 class="h1 mb-0 text-capitalize d-flex align-items-center gap-2">
                <img src="<?php echo e(asset('/public/assets/back-end/img/Pages.png')); ?>" width="20" alt="">
                <?php echo e(\App\CPU\translate('pages')); ?>

            </h2>
        </div>
        <!-- End Page Title -->

        <!-- Inlile Menu -->
        <?php echo $__env->make('admin-views.business-settings.pages-inline-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Inlile Menu -->

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><?php echo e(\App\CPU\translate('privacy_policy')); ?></h5>
                    </div>

                    <form action="<?php echo e(route('admin.business-settings.privacy-policy')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <textarea class="form-control" id="editor" name="value"><?php echo e($privacy_policy->value); ?></textarea>
                            </div>
                            <div class="form-group">
                                <input class="form-control btn--primary" type="submit" name="btn">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <!-- ck editor -->
    <script>
        ClassicEditor
        .create( document.querySelector( '#editor' ) )
            .then( editor => {
                console.log(editor);
            })
        .catch( error => {
            console.error( error );
        } );
    </script>
    <!-- ck editor -->
    
    
    
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.back-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/q291duikhtl7/public_html/khareedofarokht.pk/resources/views/admin-views/business-settings/privacy-policy.blade.php ENDPATH**/ ?>