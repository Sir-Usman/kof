<?php $__env->startSection('title', $web_config['name']->value.' '.\App\CPU\translate('Online Shopping').' | '.$web_config['name']->value.' '.\App\CPU\translate(' Ecommerce')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta property="og:image" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="og:title" content="Welcome To <?php echo e($web_config['name']->value); ?> Home"/>
    <meta property="og:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="og:description" content="<?php echo substr($web_config['about']->value,0,100); ?>">

    <meta property="twitter:card" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="twitter:title" content="Welcome To <?php echo e($web_config['name']->value); ?> Home"/>
    <meta property="twitter:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="twitter:description" content="<?php echo substr($web_config['about']->value,0,100); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('public/assets/front-end')); ?>/css/home.css"/>
    <style>
        .media {
            background: white;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
        }

        .cz-countdown-days {
            color: white !important;
            background-color: #ffffff30;
            border: .5px solid<?php echo e($web_config['primary_color']); ?>;
            padding: 0px 6px;
            border-radius: 3px;
            margin-right: 0px !important;
            display: flex;
	        flex-direction: column;
            -ms-flex: .4;  /* IE 10 */
            flex: 1;

        }

        .cz-countdown-hours {
            color: white !important;
            background-color: #ffffff30;
            border: .5px solid<?php echo e($web_config['primary_color']); ?>;
            padding: 0px 6px;
            border-radius: 3px;
            margin-right: 0px !important;
            display: flex;
	        flex-direction: column;
            -ms-flex: .4;  /* IE 10 */
            flex: 1;
        }

        .cz-countdown-minutes {
            color: white !important;
            background-color: #ffffff30;
            border: .5px solid<?php echo e($web_config['primary_color']); ?>;
            padding: 0px 6px;
            border-radius: 3px;
            margin-right: 0px !important;
            display: flex;
	        flex-direction: column;
            -ms-flex: .4;  /* IE 10 */
            flex: 1;
        }

        .cz-countdown-seconds {
            color: white !important;
            background-color: #ffffff30;
            border: .5px solid<?php echo e($web_config['primary_color']); ?>;
            padding: 0px 6px;
            border-radius: 3px;
            display: flex;
	        flex-direction: column;
            -ms-flex: .4;  /* IE 10 */
            flex: 1;
        }

        .flash_deal_product_details .flash-product-price {
            font-weight: 700;
            font-size: 18px;
            color: <?php echo e($web_config['primary_color']); ?>;
        }

        .featured_deal_left {
            height: 130px;
            background: <?php echo e($web_config['primary_color']); ?> 0% 0% no-repeat padding-box;
            padding: 10px 13px;
            text-align: center;
        }

        .category_div:hover {
            color: <?php echo e($web_config['secondary_color']); ?>;
        }

        .deal_of_the_day {
            /* filter: grayscale(0.5); */
            /* opacity: .8; */
            background: <?php echo e($web_config['secondary_color']); ?>;
            border-radius: 3px;
        }

        .deal-title {
            font-size: 12px;

        }

        .for-flash-deal-img img {
            max-width: none;
        }
        .best-selleing-image {
            background:<?php echo e($web_config['primary_color']); ?>10;
            width:30%;
            display:flex;
            align-items:center;
            border-radius: 5px;
        }
        .best-selling-details {
            padding:10px;
            width:50%;
        }
        .top-rated-image{
            background:<?php echo e($web_config['primary_color']); ?>10;
            width:30%;
            display:flex;
            align-items:center;
            border-radius: 5px;
        }
        .top-rated-details {
            padding:10px;width:70%;
        }

        @media (max-width: 375px) {
            .cz-countdown {
                display: flex !important;

            }

            .cz-countdown .cz-countdown-seconds {

                margin-top: -5px !important;
            }

            .for-feature-title {
                font-size: 20px !important;
            }
        }

        @media (max-width: 600px) {
            .flash_deal_title {
                /*font-weight: 600;*/
                /*font-size: 18px;*/
                /*text-transform: uppercase;*/

                font-weight: 700;
                font-size: 25px;
                text-transform: uppercase;
            }

            .cz-countdown .cz-countdown-value {
                /* font-family: "Roboto", sans-serif; */
                font-size: 11px !important;
                font-weight: 700 !important;

            }

            .featured_deal {
                opacity: 1 !important;
            }

            .cz-countdown {
                display: inline-block;
                flex-wrap: wrap;
                font-weight: normal;
                margin-top: 4px;
                font-size: smaller;
            }

            .view-btn-div-f {

                margin-top: 6px;
                float: right;
            }

            .view-btn-div {
                float: right;
            }

            .viw-btn-a {
                font-size: 10px;
                font-weight: 600;
            }


            .for-mobile {
                display: none;
            }

            .featured_for_mobile {
                max-width: 100%;
                margin-top: 20px;
                margin-bottom: 20px;
            }
            .best-selleing-image {
                width: 50%;
                border-radius: 5px;
            }
            .best-selling-details {
                width:50%;
            }
            .top-rated-image {
                width: 50%;
            }
            .top-rated-details {
            width:50%;
        }
        }


        @media (max-width: 360px) {
            .featured_for_mobile {
                max-width: 100%;
                margin-top: 10px;
                margin-bottom: 10px;
            }

            .featured_deal {
                opacity: 1 !important;
            }
        }

        @media (max-width: 375px) {
            .featured_for_mobile {
                max-width: 100%;
                margin-top: 10px;
                margin-bottom: 10px;
            }

            .featured_deal {
                opacity: 1 !important;
            }

        }

        @media (min-width: 768px) {
            .displayTab {
                display: block !important;
            }

        }

        @media (max-width: 800px) {

            .latest-product-margin {
                margin-left: 0px !important;
                }
            .for-tab-view-img {
                width: 40%;
            }

            .for-tab-view-img {
                width: 105px;
            }

            .widget-title {
                font-size: 19px !important;
            }
            .flash-deal-view-all-web {
                display: none !important;
            }
            .categories-view-all {
                <?php echo e(session('direction') === "rtl" ? 'margin-left: 10px;' : 'margin-right: 6px;'); ?>

            }
            .categories-title {
                <?php echo e(Session::get('direction') === "rtl" ? 'margin-right: 0px;' : 'margin-left: 6px;'); ?>

            }
            .seller-list-title{
                <?php echo e(Session::get('direction') === "rtl" ? 'margin-right: 0px;' : 'margin-left: 10px;'); ?>

            }
            .seller-list-view-all {
                <?php echo e(Session::get('direction') === "rtl" ? 'margin-left: 20px;' : 'margin-right: 10px;'); ?>

            }
            .seller-card {
                padding-left: 0px !important;
            }
            .category-product-view-title {
                <?php echo e(Session::get('direction') === "rtl" ? 'margin-right: 16px;' : 'margin-left: -8px;'); ?>

            }
            .category-product-view-all {
                <?php echo e(Session::get('direction') === "rtl" ? 'margin-left: -7px;' : 'margin-right: 5px;'); ?>

            }
            .recomanded-product-card {
                background: #F8FBFD;margin:20px;height: 535px; border-radius: 5px;
            }
            .recomanded-buy-button {
                text-align: center;
                margin-top: 30px;
            }
        }
        @media(min-width:801px){
            .flash-deal-view-all-mobile{
                display: none !important;
            }
            .categories-view-all {
                <?php echo e(session('direction') === "rtl" ? 'margin-left: 30px;' : 'margin-right: 27px;'); ?>

            }
            .categories-title {
                <?php echo e(Session::get('direction') === "rtl" ? 'margin-right: 25px;' : 'margin-left: 25px;'); ?>

            }
            .seller-list-title{
                <?php echo e(Session::get('direction') === "rtl" ? 'margin-right: 6px;' : 'margin-left: 10px;'); ?>

            }
            .seller-list-view-all {
                <?php echo e(Session::get('direction') === "rtl" ? 'margin-left: 12px;' : 'margin-right: 10px;'); ?>

            }
            .seller-card {
                <?php echo e(Session::get('direction') === "rtl" ? 'padding-left:0px !important;' : 'padding-right:0px !important;'); ?>

            }
            .category-product-view-title {
                <?php echo e(Session::get('direction') === "rtl" ? 'margin-right: 10px;' : 'margin-left: -12px;'); ?>

            }
            .category-product-view-all {
                <?php echo e(Session::get('direction') === "rtl" ? 'margin-left: -20px;' : 'margin-right: 0px;'); ?>

            }
            .recomanded-product-card {
                background: #F8FBFD;margin:20px;height: 475px; border-radius: 5px;
            }
            .recomanded-buy-button {
                text-align: center;
                margin-top: 63px;
            }

        }

        .featured_deal_carosel .carousel-inner {
            width: 100% !important;
        }

        .badge-style2 {
            color: black !important;
            background: transparent !important;
            font-size: 11px;
        }
        .countdown-card{
            background:<?php echo e($web_config['primary_color']); ?>10;
            height: 150px!important;
            border-radius:5px;

        }
        .flash-deal-text{
            color: <?php echo e($web_config['primary_color']); ?>;
            text-transform: uppercase;
            text-align:center;
            font-weight:700;
            font-size:20px;
            border-radius:5px;
            margin-top:25px;
        }
        .countdown-background{
            background: <?php echo e($web_config['primary_color']); ?>;
            padding: 5px 5px;
            border-radius:5px;
            margin-top:15px;
        }
        .carousel-wrap{
            position: relative;
        }
        .owl-nav{
            top: 40%;
            position: absolute;
            display: flex;
            justify-content: space-between;
            width: 100%;
        }
     }
     .owl-prev{
         float: left;

     }
     .owl-next{
         float: right;
     }
     .czi-arrow-left{
        color: <?php echo e($web_config['primary_color']); ?>;
        background: <?php echo e($web_config['primary_color']); ?>10;
        padding: 5px;
        border-radius: 50%;
        margin-left: -12px;
        font-weight: bold;
        font-size: 12px;
     }
     .czi-arrow-right{
        color: <?php echo e($web_config['primary_color']); ?>;
        background: <?php echo e($web_config['primary_color']); ?>10;
        padding: 5px;
        border-radius: 50%;
        margin-right: -15px;
        font-weight: bold;
        font-size: 12px;
     }
    .owl-carousel .nav-btn .czi-arrow-left{
      height: 47px;
      position: absolute;
      width: 26px;
      cursor: pointer;
      top: 100px !important;
  }
  .flash-deals-background-image{
    background: <?php echo e($web_config['primary_color']); ?>10;
    border-radius:5px;
    width:125px;
    height:125px;
  }
  .view-all-text{
    color:<?php echo e($web_config['secondary_color']); ?> !important;
    font-size:14px;
  }
  .feature-product-title {
    text-align: center;
    font-size: 22px;
    margin-top: 15px;
    font-style: normal;
    font-weight: 700;
  }
  .feature-product .czi-arrow-left{
        color: <?php echo e($web_config['primary_color']); ?>;
        background: <?php echo e($web_config['primary_color']); ?>10;
        padding: 5px;
        border-radius: 50%;
        margin-left: -80px;
        font-weight: bold;
        font-size: 12px;
     }

     .feature-product .owl-nav{
        top: 40%;
        position: absolute;
        display: flex;
        justify-content: space-between;
        /* width: 100%; */
        z-index: -999;
    }
     .feature-product .czi-arrow-right{
        color: <?php echo e($web_config['primary_color']); ?>;
        background: <?php echo e($web_config['primary_color']); ?>10;
        padding: 5px;
        border-radius: 50%;
        margin-right: -80px;
        font-weight: bold;
        font-size: 12px;
     }
     .shipping-policy-web{
        background: #ffffff;width:100%; border-radius:5px;
     }
     .shipping-method-system{
        height: 130px;width: 70%;margin-top: 15px;
     }

     .flex-between {
         display: flex;
         justify-content: space-between;
     }
     .new_arrival_product .czi-arrow-left{
         margin-left: -28px;
     }
     .new_arrival_product .owl-nav{
         z-index: -999;
     }
    </style>

    <link rel="stylesheet" href="<?php echo e(asset('public/assets/front-end')); ?>/css/owl.carousel.min.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/front-end')); ?>/css/owl.theme.default.min.css"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php ($decimal_point_settings = !empty(\App\CPU\Helpers::get_business_settings('decimal_point_settings')) ? \App\CPU\Helpers::get_business_settings('decimal_point_settings') : 0); ?>
    <!-- Hero (Banners + Slider)-->
    <section class="bg-transparent mb-3">
        <div class="container">
            <div class="row ">
                <div class="col-12">
                    <?php echo $__env->make('web-views.partials._home-top-slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </section>

    
    <?php ($flash_deals=\App\Model\FlashDeal::with(['products'=>function($query){
                $query->with('product')->whereHas('product',function($q){
                    $q->active();
                });
            }])->where(['status'=>1])->where(['deal_type'=>'flash_deal'])->whereDate('start_date','<=',date('Y-m-d'))->whereDate('end_date','>=',date('Y-m-d'))->first()); ?>

    <?php if(isset($flash_deals)): ?>
    <div class="container">
        <div class="flash-deal-view-all-web row d-flex justify-content-<?php echo e(Session::get('direction') === "rtl" ? 'start' : 'end'); ?>" style="<?php echo e(Session::get('direction') === "rtl" ? 'margin-left: 2px;' : 'margin-right:2px;'); ?>">
            <?php if(count($flash_deals->products)>0): ?>
                <a class="text-capitalize view-all-text" href="<?php echo e(route('flash-deals',[isset($flash_deals)?$flash_deals['id']:0])); ?>">
                    <?php echo e(\App\CPU\translate('view_all')); ?>

                    <i class="czi-arrow-<?php echo e(Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'); ?>"></i>
                </a>
            <?php endif; ?>
        </div>
        <div class="row d-flex <?php echo e(Session::get('direction') === "rtl" ? 'flex-row-reverse' : 'flex-row'); ?>">


            <div class="col-md-3 mt-2 countdown-card" >
                <div class="m-2">
                    <div class="flash-deal-text">
                        <span><?php echo e(\App\CPU\translate('flash deal')); ?></span>
                    </div>
                    <div style=" text-align: center;color: #ffffff !important;">
                        <div class="countdown-background">
                            <span class="cz-countdown d-flex justify-content-center align-items-center"
                                data-countdown="<?php echo e(isset($flash_deals)?date('m/d/Y',strtotime($flash_deals['end_date'])):''); ?> 11:59:00 PM">
                                <span class="cz-countdown-days">
                                    <span class="cz-countdown-value"></span>
                                    <span><?php echo e(\App\CPU\translate('day')); ?></span>
                                </span>
                                <span class="cz-countdown-value p-1">:</span>
                                <span class="cz-countdown-hours">
                                    <span class="cz-countdown-value"></span>
                                    <span><?php echo e(\App\CPU\translate('hrs')); ?></span>
                                </span>
                                <span class="cz-countdown-value p-1">:</span>
                                <span class="cz-countdown-minutes">
                                    <span class="cz-countdown-value"></span>
                                    <span><?php echo e(\App\CPU\translate('min')); ?></span>
                                </span>
                                <span class="cz-countdown-value p-1">:</span>
                                <span class="cz-countdown-seconds">
                                    <span class="cz-countdown-value"></span>
                                    <span><?php echo e(\App\CPU\translate('sec')); ?></span>
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flash-deal-view-all-mobile col-md-12" style="<?php echo e(Session::get('direction') === "rtl" ? 'margin-left: 2px;' : 'margin-right:2px;'); ?>">
                <a class="<?php echo e(Session::get('direction') === "rtl" ? 'float-left' : 'float-right'); ?> mt-2 text-capitalize view-all-text" href="<?php echo e(route('flash-deals',[isset($flash_deals)?$flash_deals['id']:0])); ?>">
                    <?php echo e(\App\CPU\translate('view_all')); ?>

                    <i class="czi-arrow-<?php echo e(Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'); ?>"></i>
                </a>
            </div>
            <div class="col-md-9 <?php echo e(Session::get('direction') === "rtl" ? 'pr-md-4' : 'pl-md-4'); ?>">
                <div class="carousel-wrap">
                    <div class="owl-carousel owl-theme mt-2" id="flash-deal-slider">
                        <?php $__currentLoopData = $flash_deals->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( $deal->product): ?>
                                <?php echo $__env->make('web-views.partials._product-card-1',['product'=>$deal->product,'decimal_point_settings'=>$decimal_point_settings], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    
<?php if($brand_setting): ?>
    <section class="container rtl mt-3-">
        <!-- Heading-->
        
    
    <!-- Grid-->

        <div class="mt-3- mb-3- brand-slider">
            <div class="owl-carousel owl-theme p-2" id="brands-slider">
                <div class="text-center">
                    <a href="<?php echo e(route('brands')); ?>">
                        <div class="d-flex align-items-center justify-content-center border border-primary shadow"
                             style="height:70px; width:70px; margin:20px 0px; border-radius:50%">
                             <?php echo e(\App\CPU\translate('All')); ?>

                        </div>
                    </a>
                </div>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center">
                        <a href="<?php echo e(route('products',['id'=> $brand['id'],'data_from'=>'brand','page'=>1])); ?>">
                            <div class="d-flex align-items-center justify-content-center"
                                 style="height:100px;margin:5px;">
                                <img style="border-radius: 50%;"
                                    onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                                    src="<?php echo e(asset("storage/app/public/brand/$brand->image")); ?>" alt="<?php echo e($brand->name); ?>">
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>

    <!-- Products grid (featured products)-->
    <?php if($featured_products->count() > 0 ): ?>
    <div class="container mb-4">
        <div class="row" style="background: white;box-shadow: 0px 3px 6px #0000000d;border-radius: 5px;">
            <div class="col-md-12" >
                <div class="feature-product-title">
                    <?php echo e(\App\CPU\translate('featured_products')); ?>

                </div>
            </div>
            <div class="col-md-12">
                <div class="feature-product" style="padding-left:55px;padding-right: 55px;padding-top: 10px;">
                    <div class="carousel-wrap p-1">
                        <div class="owl-carousel owl-theme " id="featured_products_list">
                            <?php $__currentLoopData = $featured_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div  style="margin:5px;margin-bottom: 30px;">
                                    <?php echo $__env->make('web-views.partials._feature-product',['product'=>$product, 'decimal_point_settings'=>$decimal_point_settings], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    
    <?php ($featured_deals=\App\Model\FlashDeal::with(['products'=>function($query_one){
        $query_one->with('product.reviews')->whereHas('product',function($query_two){
            $query_two->active();
        });
    }])
    ->whereDate('start_date', '<=', date('Y-m-d'))->whereDate('end_date', '>=', date('Y-m-d'))
    ->where(['status'=>1])->where(['deal_type'=>'feature_deal'])
    ->first()); ?>

    <?php if(isset($featured_deals)): ?>
        <section class="container featured_deal rtl mb-2">
            <div class="row" style="background: <?php echo e($web_config['primary_color']); ?>;padding:5px;padding-bottom: 25px; border-radius:5px;">
                <div class="col-12 pb-2" >
                    <?php if(count($featured_deals->products)>0): ?>
                        <a class="text-capitalize mt-2 mt-md-0 <?php echo e(Session::get('direction') === "rtl" ? 'float-left' : 'float-right'); ?>" href="<?php echo e(route('products',['data_from'=>'featured_deal'])); ?>"
                            style="color: white !important;<?php echo e(Session::get('direction') === "rtl" ? 'margin-left: 21px;' : 'margin-right: 21px;'); ?>">
                            <?php echo e(\App\CPU\translate('view_all')); ?>

                            <i class="czi-arrow-<?php echo e(Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'); ?>"></i>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="col-xl-3 col-md-4 d-flex align-items-center justify-content-center right">
                    <div class="m-4">
                        <span class="featured_deal_title"
                            style="padding-top: 12px"><?php echo e(\App\CPU\translate('featured_deal')); ?></span>
                        <br>

                        <span style="color: white;text-align: left !important;"><?php echo e(\App\CPU\translate('See the latest deals and exciting new offers ')); ?>!</span>

                    </div>

                </div>

                <div class="col-xl-9 col-md-8 d-flex align-items-center justify-content-center <?php echo e(Session::get('direction') === "rtl" ? 'pl-4' : 'pr-4'); ?>">
                    <div class="owl-carousel owl-theme" id="web-feature-deal-slider">
                        <?php $__currentLoopData = $featured_deals->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('web-views.partials._feature-deal-product',['product'=>$product->product, 'decimal_point_settings'=>$decimal_point_settings], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
    
    <div class="container rtl">
        <div class="row ">
            
            <div class="col-xl-3 col-md-4 pb-4 mt-3 pl-0 pr-0">
                <div class="deal_of_the_day shadow2 rounded-lg2" style="background: <?php echo e($web_config['primary_color']); ?>;height: 754px;">
                    <?php if(isset($deal_of_the_day) && isset($deal_of_the_day->product)): ?>
                        <div class="d-flex justify-content-center align-items-center" style="width: 70%;margin:auto;">
                            <h1 class="align-items-center" style="color: white"> <?php echo e(\App\CPU\translate('deal_of_the_day')); ?></h1>
                        </div>
                        <div class="recomanded-product-card">

                            <div class="d-flex justify-content-center align-items-center" style="margin:20px 20px -20px 20px;padding-top: 20px;">
                                <img style="border-radius:5px 5px 0px opx;"
                                    src="<?php echo e(\App\CPU\ProductManager::product_image_path('thumbnail')); ?>/<?php echo e($deal_of_the_day->product['thumbnail']); ?>"
                                    onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                                    alt="">
                            </div>
                            <div style="background:#ffffff;margin:20px;padding-top: 10px;height: 200px;border-radius: 0px 0px 5px 5px;">
                                <div style="text-align: left; padding: 20px;">

                                    <?php ($overallRating = \App\CPU\ProductManager::get_overall_rating($deal_of_the_day->product['reviews'])); ?>
                                    <div class="rating-show" style="height:125px; ">
                                        <h5 style="font-weight: 600; color: <?php echo e($web_config['primary_color']); ?>">
                                            <?php echo e(\Illuminate\Support\Str::limit($deal_of_the_day->product['name'],30)); ?>

                                        </h5>
                                        <span class="d-inline-block font-size-sm text-body">
                                            <?php for($inc=0;$inc<5;$inc++): ?>
                                                <?php if($inc<$overallRating[0]): ?>
                                                    <i class="sr-star czi-star-filled active"></i>
                                                <?php else: ?>
                                                    <i class="sr-star czi-star" style="color:#fea569 !important"></i>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                            <label class="badge-style">( <?php echo e($deal_of_the_day->product->reviews_count); ?> )</label>
                                        </span>
                                    </div>
                                    <div class="float-right">

                                        <?php if($deal_of_the_day->product->discount > 0): ?>
                                            <strike style="font-size: 12px!important;color: #E96A6A!important;">
                                                <?php echo e(\App\CPU\Helpers::currency_converter($deal_of_the_day->product->unit_price)); ?>

                                            </strike>
                                        <?php endif; ?>
                                        <span class="text-accent" style="margin: 10px;font-size: 22px !important;">
                                            <?php echo e(\App\CPU\Helpers::currency_converter(
                                                $deal_of_the_day->product->unit_price-(\App\CPU\Helpers::get_product_discount($deal_of_the_day->product,$deal_of_the_day->product->unit_price))
                                            )); ?>

                                        </span>

                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="recomanded-buy-button">
                            <button class="buy_btn" style="color:<?php echo e($web_config['primary_color']); ?>"
                                    onclick="location.href='<?php echo e(route('product',$deal_of_the_day->product->slug)); ?>'"><?php echo e(\App\CPU\translate('buy_now')); ?>

                            </button>
                        </div>
                    <?php else: ?>
                        <?php ($product=\App\Model\Product::active()->inRandomOrder()->first()); ?>
                        <?php if(isset($product)): ?>
                            <div class="d-flex justify-content-center align-items-center">
                                <h1 style="color: white"> <?php echo e(\App\CPU\translate('recommended_product')); ?></h1>
                            </div>
                            <div class="recomanded-product-card">
                                <div class="d-flex justify-content-center align-items-center" style="margin:20px 20px -20px 20px;padding-top: 20px;">
                                    <img style="max-height:220px" src="<?php echo e(\App\CPU\ProductManager::product_image_path('thumbnail')); ?>/<?php echo e($product['thumbnail']); ?>"
                                        onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'" alt="">
                                </div>
                                <div style="background:#ffffff;margin:20px;padding-top: 10px;border-radius: 0px 0px 5px 5px;">
                                    <div style="text-align: left; padding: 20px;">
                                        <?php ($overallRating = \App\CPU\ProductManager::get_overall_rating($product['reviews'])); ?>
                                        <div class="rating-show">
                                            <h5 style="font-weight: 600; color: <?php echo e($web_config['primary_color']); ?>; height:50px; overflow: hidden; text-overflow: ellipsis;">
                                                <?php echo e(\Illuminate\Support\Str::limit($product['name'],40)); ?>

                                            </h5>
                                            <span class="d-inline-block font-size-sm text-body bg-white">
                                                <?php for($inc=0;$inc<5;$inc++): ?>
                                                    <?php if($inc<$overallRating[0]): ?>
                                                        <i class="sr-star czi-star-filled active"></i>
                                                    <?php else: ?>
                                                        <i class="sr-star czi-star" style="color:#fea569 !important"></i>
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                                <label class="badge-style">( <?php echo e($product->reviews_count); ?> )</label>
                                            </span>
                                        </div>
                                        <div class="float-right">
                                            <?php if($product->discount > 0): ?>
                                                <strike style="font-size: 12px!important;color: #E96A6A!important;">
                                                    <?php echo e(\App\CPU\Helpers::currency_converter($product->unit_price)); ?>

                                                </strike>
                                            <?php endif; ?>
                                            <span class="text-accent" style="margin: 10px;font-size: 22px !important;">
                                                <?php echo e(\App\CPU\Helpers::currency_converter(
                                                    $product->unit_price-(\App\CPU\Helpers::get_product_discount($product,$product->unit_price))
                                                )); ?>

                                            </span>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="recomanded-buy-button">
                                <button class="buy_btn" style="color:<?php echo e($web_config['primary_color']); ?>" onclick="location.href='<?php echo e(route('product',$product->slug)); ?>'"><?php echo e(\App\CPU\translate('buy_now')); ?></button>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-xl-9 col-md-8 mt-2 pl-0 pr-0">
                <div class="latest-product-margin" style="margin-<?php echo e(Session::get('direction') === "rtl" ? 'right:30px' : 'left:30px'); ?>">
                    <div class="d-flex justify-content-between">
                        <div class="" style="text-align: center;">
                            <span class="for-feature-title" style="text-align: center;font-size:22px !important; font-weight:700"><?php echo e(\App\CPU\translate('latest_products')); ?></span>
                        </div>
                        <div style="margin-right: 4px;">
                            <a class="text-capitalize view-all-text"
                               href="<?php echo e(route('products',['data_from'=>'latest'])); ?>">
                                <?php echo e(\App\CPU\translate('view_all')); ?>

                                <i class="czi-arrow-<?php echo e(Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'); ?>"></i>
                            </a>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <?php $__currentLoopData = $latest_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-3 col-sm-6 col-md-6 col-6 mb-4">
                                <div style="margin:2px;">
                                    <?php echo $__env->make('web-views.partials._single-product',['product'=>$product,'decimal_point_settings'=>$decimal_point_settings], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php ($main_section_banner = \App\Model\Banner::where('banner_type','Main Section Banner')->where('published',1)->orderBy('id','desc')->latest()->first()); ?>
    <?php if(isset($main_section_banner)): ?>
    <div class="container rtl mb-3">
        <div class="row" >
            <div class="col-12 pl-0 pr-0">
                <a href="<?php echo e($main_section_banner->url); ?>" style="cursor: pointer;">
                    <img class="d-block footer_banner_img" style="width: 100%;border-radius: 5px;height: auto !important;" onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'" src="<?php echo e(asset('storage/app/public/banner')); ?>/<?php echo e($main_section_banner['photo']); ?>">
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php ($business_mode=\App\CPU\Helpers::get_business_settings('business_mode')); ?>
    
    <div class="container rtl">
        <div class="row">
            <?php if($business_mode == 'multi'): ?>
                <div class="col-md-12 <?php echo e(Session::get('direction') === "rtl" ? 'pr-0' : 'pl-0'); ?>">
                    <div class="card shadow2 rounded-lg2">
                        <div class="card-body py-0">
                            
                            <div class="row d-flex- justify-content-center-">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key<10): ?>
                                        <div class="text-center col-4 col-md-2 my-3">
                                            <a href="<?php echo e(route('products',['id'=> $category['id'],'data_from'=>'category','page'=>1])); ?>">
                                                <img style="border-radius: 5px; height: 100px;" onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'" src="<?php echo e(asset("storage/app/public/category/$category->icon")); ?>" alt="<?php echo e($category->name); ?>">
                                                <p class="text-center small mt-3 mb-0"><?php echo e(Str::limit($category->name, 12)); ?></p>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="col-md-12 pl-0 pr-0">
                    <div class="card shadow2 rounded-lg2" style="min-height: 232px;">
                        <div class="card-body">
                            <div class="row d-flex justify-content-between">
                                <div style="<?php echo e(Session::get('direction') === "rtl" ? 'margin-right: 20px;' : 'margin-left: 22px;'); ?>">
                                    <span style="font-weight: 600;font-size: 16px;"><?php echo e(\App\CPU\translate('categories')); ?></span>
                                </div>
                                <div style="<?php echo e(Session::get('direction') === "rtl" ? 'margin-left: 15px;' : 'margin-right: 13px;'); ?>">
                                    <a class="text-capitalize view-all-text"
                                    href="<?php echo e(route('categories')); ?>"><?php echo e(\App\CPU\translate('view_all')); ?>

                                    <i class="czi-arrow-<?php echo e(Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'); ?>"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="row d-flex justify-content-center mt-3">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key<11): ?>
                                        <div class="text-center"  style="margin: 5px;">
                                            <a href="<?php echo e(route('products',['id'=> $category['id'],'data_from'=>'category','page'=>1])); ?>">
                                                <img style="vertical-align: middle; height: 100px;border-radius: 5px;"
                                                    onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                                                    src="<?php echo e(asset("storage/app/public/category/$category->icon")); ?>"
                                                    alt="<?php echo e($category->name); ?>">
                                                <p class="text-center small "
                                                style="margin-top: 5px"><?php echo e(Str::limit($category->name, 12)); ?></p>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <!-- top sellers -->

        
        </div>
    </div>


    
    <div class="container rtl my-3" style="">
        <div class="col-md-12 shadow2 rounded-lg2" style="background-color:white;padding:20px;">
            <div class="new_arrival_product" style="margin-left:-5px;">
                <div class="carousel-wrap" >
                    <div class="owl-carousel owl-theme p-2" id="new-arrivals-product">
                        <?php $__currentLoopData = $latest_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php echo $__env->make('web-views.partials._product-card-1',['product'=>$product,'decimal_point_settings'=>$decimal_point_settings], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container rtl">
        <div class="row">
            <div class="col-md-6 ">
                <div class="card">
                    <div class="card-body">
                        <div class="row d-flex justify-content-between m-3">
                            <div>
                                <img style="height:30px;width:30px;"  src="<?php echo e(asset("public/assets/front-end/png/best sellings.png")); ?>"
                                         alt="">
                                    <span style="margin-left:10px;text-transform: uppercase;font-weight: 700;"><?php echo e(\App\CPU\translate('best sellings')); ?></span>
                            </div>
                            <div>
                                <a class="text-capitalize view-all-text"
                                    href="<?php echo e(route('products',['data_from'=>'best-selling','page'=>1])); ?>"><?php echo e(\App\CPU\translate('view_all')); ?>

                                    <i class="czi-arrow-<?php echo e(Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'); ?>"></i>
                                </a>
                            </div>
                        </div>
                        <div class="row ml-2 mr-3 mb-2">
                            <?php $__currentLoopData = $bestSellProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bestSell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($bestSell->product && $key<3): ?>
                                    <div class="col-12 m-1" style="border-style: solid;
                                    border-color: #0000000d; border-radius:5px;"
                                         data-href="<?php echo e(route('product',$bestSell->product->slug)); ?>">
                                         <?php if($bestSell->product->discount > 0): ?>
                                                <div class="d-flex" style="top:0;position:absolute;<?php echo e(Session::get('direction') === "rtl" ? 'right:0;' : 'left:0;'); ?>">
                                                    <span class="for-discoutn-value p-1 pl-2 pr-2" style="<?php echo e(Session::get('direction') === "rtl" ? 'border-radius:0px 5px' : 'border-radius:5px 0px'); ?>;">
                                                        <?php if($bestSell->product->discount_type == 'percent'): ?>
                                                            <?php echo e(round($bestSell->product->discount)); ?>%
                                                        <?php elseif($bestSell->product->discount_type =='flat'): ?>
                                                            <?php echo e(\App\CPU\Helpers::currency_converter($bestSell->product->discount)); ?>

                                                        <?php endif; ?> <?php echo e(\App\CPU\translate('off')); ?>

                                                    </span>
                                                </div>
                                            <?php endif; ?>
                                        <div class="row" style="padding:8px;">

                                            <div class="best-selleing-image"  >
                                                <a class="d-block d-flex justify-content-center" style="width:100%;height:100%;"
                                                    href="<?php echo e(route('product',$bestSell->product->slug)); ?>">
                                                    <img style="border-radius:5px;"
                                                        onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                                                        src="<?php echo e(\App\CPU\ProductManager::product_image_path('thumbnail')); ?>/<?php echo e($bestSell->product['thumbnail']); ?>"
                                                        alt="Product"/>
                                                </a>
                                            </div>
                                            <div class="best-selling-details" style="">
                                                <h6 class="widget-product-title">
                                                    <a class="ptr"
                                                    href="<?php echo e(route('product',$bestSell->product->slug)); ?>">
                                                        <?php echo e(\Illuminate\Support\Str::limit($bestSell->product['name'],100)); ?>

                                                    </a>
                                                </h6>
                                                <?php ($bestSell_overallRating = \App\CPU\ProductManager::get_overall_rating($bestSell->product['reviews'])); ?>
                                                <div class="rating-show">
                                                    <span class="d-inline-block font-size-sm text-body">
                                                        <?php for($inc=0;$inc<5;$inc++): ?>
                                                            <?php if($inc<$bestSell_overallRating[0]): ?>
                                                                <i class="sr-star czi-star-filled active"></i>
                                                            <?php else: ?>
                                                                <i class="sr-star czi-star" style="color:#fea569 !important"></i>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                        <label class="badge-style">( <?php echo e($bestSell->product->reviews_count); ?> )</label>
                                                    </span>
                                                </div>
                                                <div>
                                                    <?php if($bestSell->product->discount > 0): ?>
                                                            <strike style="font-size: 12px!important;color: #E96A6A!important;">
                                                                <?php echo e(\App\CPU\Helpers::currency_converter($bestSell->product->unit_price)); ?>

                                                            </strike>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="widget-product-meta">
                                                    <span class="text-accent">
                                                        <?php echo e(\App\CPU\Helpers::currency_converter(
                                                        $bestSell->product->unit_price-(\App\CPU\Helpers::get_product_discount($bestSell->product,$bestSell->product->unit_price))
                                                        )); ?>

                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mt-2 mt-md-0">
                <div class="card">
                    <div class="card-body">
                        <div class="row d-flex justify-content-between m-3">
                            <div>
                                <img style="height:30px;width:30px;"  src="<?php echo e(asset("public/assets/front-end/png/top-rated.png")); ?>"
                                         alt="">
                                    <span style="margin-left:10px;text-transform: uppercase;font-weight: 700;"><?php echo e(\App\CPU\translate('top rated')); ?></span>
                            </div>
                            <div>
                                <a class="text-capitalize view-all-text"
                                    href="<?php echo e(route('products',['data_from'=>'top-rated','page'=>1])); ?>"><?php echo e(\App\CPU\translate('view_all')); ?>

                                    <i class="czi-arrow-<?php echo e(Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'); ?>"></i>
                                </a>
                            </div>
                        </div>
                        <div class="row ml-2 mr-3 mb-2">
                            <?php $__currentLoopData = $topRated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($top->product && $key<3): ?>
                                    <div class="col-12 m-1" style="border-style: solid;
                                    border-color: #0000000d; border-radius:5px;"
                                         data-href="<?php echo e(route('product',$top->product->slug)); ?>">
                                         <?php if($top->product->discount > 0): ?>
                                                <div class="d-flex" style="top:0;position:absolute;<?php echo e(Session::get('direction') === "rtl" ? 'right:0;' : 'left:0;'); ?>">
                                                    <span class="for-discoutn-value p-1 pl-2 pr-2" style="<?php echo e(Session::get('direction') === "rtl" ? 'border-radius:0px 5px' : 'border-radius:5px 0px'); ?>;">
                                                        <?php if($top->product->discount_type == 'percent'): ?>
                                                            <?php echo e(round($top->product->discount)); ?>%
                                                        <?php elseif($top->product->discount_type =='flat'): ?>
                                                            <?php echo e(\App\CPU\Helpers::currency_converter($top->product->discount)); ?>

                                                        <?php endif; ?> <?php echo e(\App\CPU\translate('off')); ?>

                                                    </span>
                                                </div>
                                            <?php endif; ?>
                                        <div class="row" style="padding:8px;">

                                            <div class="top-rated-image">
                                                <a class="d-block d-flex justify-content-center" style="width:100%;height:100%;"
                                                    href="<?php echo e(route('product',$top->product->slug)); ?>">
                                                    <img style="border-radius:5px;"
                                                        onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                                                        src="<?php echo e(\App\CPU\ProductManager::product_image_path('thumbnail')); ?>/<?php echo e($top->product['thumbnail']); ?>"
                                                        alt="Product"/>
                                                </a>
                                            </div>
                                            <div class="top-rated-details" >
                                                <h6 class="widget-product-title">
                                                    <a class="ptr"
                                                    href="<?php echo e(route('product',$top->product->slug)); ?>">
                                                        <?php echo e(\Illuminate\Support\Str::limit($top->product['name'],100)); ?>

                                                    </a>
                                                </h6>
                                                <?php ($top_overallRating = \App\CPU\ProductManager::get_overall_rating($top->product['reviews'])); ?>
                                                <div class="rating-show">
                                                    <span class="d-inline-block font-size-sm text-body">
                                                        <?php for($inc=0;$inc<5;$inc++): ?>
                                                            <?php if($inc<$top_overallRating[0]): ?>
                                                                <i class="sr-star czi-star-filled active"></i>
                                                            <?php else: ?>
                                                                <i class="sr-star czi-star" style="color:#fea569 !important"></i>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                        <label class="badge-style">( <?php echo e($top->product->reviews_count); ?> )</label>
                                                    </span>
                                                </div>
                                                <div>
                                                    <?php if($top->product->discount > 0): ?>
                                                            <strike style="font-size: 12px!important;color: #E96A6A!important;">
                                                                <?php echo e(\App\CPU\Helpers::currency_converter($top->product->unit_price)); ?>

                                                            </strike>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="widget-product-meta">
                                                    <span class="text-accent">
                                                        <?php echo e(\App\CPU\Helpers::currency_converter(
                                                        $top->product->unit_price-(\App\CPU\Helpers::get_product_discount($top->product,$top->product->unit_price))
                                                        )); ?>

                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="container rtl mt-3 mb-3">
        <div class="row">
            <?php $__currentLoopData = \App\Model\Banner::where('banner_type','Footer Banner')->where('published',1)->orderBy('id','desc')->take(2)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mt-2 mt-md-0">
                    <a href="<?php echo e($banner->url); ?>"
                        style="cursor: pointer;">
                         <img class="" style="width: 100%; border-radius:5px;height:auto;"
                              onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                              src="<?php echo e(asset('storage/app/public/banner')); ?>/<?php echo e($banner['photo']); ?>">
                     </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
    <?php $__currentLoopData = $home_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($category['products']) > 0): ?>
            <section class="container rtl mb-3">
                <!-- Heading-->
                <div style="background: #ffffff; padding:20px;border-radius:5px;" class="shadow2 rounded-lg2">
                    <div class="flex-between pl-4">
                        <div class="category-product-view-title" >
                            <span class="for-feature-title <?php echo e(Session::get('direction') === "rtl" ? 'float-right' : 'float-left'); ?>"
                                    style="font-weight: 700;font-size: 20px;text-transform: uppercase;<?php echo e(Session::get('direction') === "rtl" ? 'text-align:right;' : 'text-align:left;'); ?>">
                                    <?php echo e(Str::limit($category['name'],18)); ?>

                            </span>
                        </div>
                        <div class="category-product-view-all" >
                            <a class="text-capitalize view-all-text "
                                href="<?php echo e(route('products',['id'=> $category['id'],'data_from'=>'category','page'=>1])); ?>"><?php echo e(\App\CPU\translate('view_all')); ?>

                                <i class="czi-arrow-<?php echo e(Session::get('direction') === "rtl" ? 'left-circle mr-1 ml-n1 mt-1 float-left' : 'right-circle ml-1 mr-n1'); ?>"></i>
                            </a>

                        </div>
                    </div>

                    <div class="row mt-2 mb-3 d-flex justify-content-between">
                        <div class="col-md-3 col-12 pl-3 pr-3">
                            <a href="<?php echo e(route('products',['id'=> $category['id'],'data_from'=>'category','page'=>1])); ?>"
                                style="cursor: pointer;">
                                <img class="" style="width: 100%; border-radius:5px;height: 300px;"
                                    onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                                    src="<?php echo e(asset('storage/app/public/category')); ?>/<?php echo e($category['icon']); ?>">
                            </a>
                        </div>
                        <div class="col-md-9 col-12 ">
                            <div class="row d-flex" >
                                <?php $__currentLoopData = $category['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key<4): ?>
                                    <div class="col-md-3 col-6 mt-2 mt-md-0" style="">
                                        <?php echo $__env->make('web-views.partials._category-single-product',['product'=>$product,'decimal_point_settings'=>$decimal_point_settings], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>


                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        

    <div class="container rtl mb-3">
        <div class="row shipping-policy-web shadow2 rounded-lg2" style="margin-right: 0px; margin-left:0px;">
            <div class="col-md-3 d-flex justify-content-center">
                <div class="shipping-method-system" >
                    <div style="text-align: center;">
                        <img style="height: 60px;width:60px;" src="<?php echo e(asset("public/assets/front-end/png/delivery.png")); ?>"
                                 alt="">
                    </div>
                    <div style="text-align: center;">
                        <p>
                        <?php echo e(\App\CPU\translate('Fast Delivery all accross the country')); ?>

                    </p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 d-flex justify-content-center">
                <div class="shipping-method-system">
                    <div style="text-align: center;">
                        <img style="height: 60px;width:60px;" src="<?php echo e(asset("public/assets/front-end/png/Payment.png")); ?>"
                                 alt="">
                    </div>
                    <div style="text-align: center;">
                        <p>
                        <?php echo e(\App\CPU\translate('Safe Payment')); ?>

                    </p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 d-flex justify-content-center">
                <div class="shipping-method-system">
                    <div style="text-align: center;">
                        <img style="height: 60px;width:60px;" src="<?php echo e(asset("public/assets/front-end/png/money.png")); ?>"
                                 alt="">
                    </div>
                    <div style="text-align: center;">
                        <p>
                        <?php echo e(\App\CPU\translate('7 Days Return Policy')); ?>

                    </p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 d-flex justify-content-center">
                <div class="shipping-method-system">
                    <div style="text-align: center;">
                        <img style="height: 60px;width:60px;" src="<?php echo e(asset("public/assets/front-end/png/Genuine.png")); ?>"
                                 alt="">
                    </div>
                    <div style="text-align: center;">
                        <p>
                        <?php echo e(\App\CPU\translate('100% Authentic Products')); ?>

                    </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    
    <script src="<?php echo e(asset('public/assets/front-end')); ?>/js/owl.carousel.min.js"></script>

    <script>
        $('#flash-deal-slider').owlCarousel({
            loop: false,
            autoplay: false,
            margin: 5,
            nav: true,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '<?php echo e(session('direction')); ?>': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 2
                },
                //Extra extra large
                1400: {
                    items: 3
                }
            }
        })

        $('#web-feature-deal-slider').owlCarousel({
            loop: false,
            autoplay: true,
            margin: 5,
            nav: false,
            //navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '<?php echo e(session('direction')); ?>': true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 2
                },
                //Extra extra large
                1400: {
                    items: 2
                }
            }
        })

        $('#new-arrivals-product').owlCarousel({
            loop: true,
            autoplay: false,
            margin: 5,
            nav: true,
            navText: ["<i class='czi-arrow-<?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>'></i>", "<i class='czi-arrow-<?php echo e(Session::get('direction') === "rtl" ? 'left' : 'right'); ?>'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '<?php echo e(session('direction')); ?>': true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 2
                },
                //Large
                992: {
                    items: 2
                },
                //Extra large
                1200: {
                    items: 4
                },
                //Extra extra large
                1400: {
                    items: 4
                }
            }
        })
    </script>
<script>
    $('#featured_products_list').owlCarousel({
        loop: true,
            autoplay: false,
            margin: 5,
            nav: true,
            navText: ["<i class='czi-arrow-left'></i>", "<i class='czi-arrow-right'></i>"],
            dots: false,
            autoplayHoverPause: true,
            '<?php echo e(session('direction')); ?>': false,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 1
                },
                360: {
                    items: 1
                },
                375: {
                    items: 1
                },
                540: {
                    items: 2
                },
                //Small
                576: {
                    items: 2
                },
                //Medium
                768: {
                    items: 3
                },
                //Large
                992: {
                    items: 4
                },
                //Extra large
                1200: {
                    items: 5
                },
                //Extra extra large
                1400: {
                    items: 5
                }
            }
        });
</script>
    <script>
        $('#brands-slider').owlCarousel({
            loop: false,
            autoplay: false,
            margin: 10,
            nav: false,
            '<?php echo e(session('direction')); ?>': true,
            //navText: ["<i class='czi-arrow-left'></i>","<i class='czi-arrow-right'></i>"],
            // dots: true,
            dots: false,
            autoplayHoverPause: true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 2
                },
                360: {
                    items: 3
                },
                375: {
                    items: 3
                },
                540: {
                    items: 4
                },
                //Small
                576: {
                    items: 5
                },
                //Medium
                768: {
                    items: 7
                },
                //Large
                992: {
                    items: 9
                },
                //Extra large
                1200: {
                    items: 11
                },
                //Extra extra large
                1400: {
                    items: 12
                }
            }
        })
    </script>

    <script>
        $('#category-slider, #top-seller-slider').owlCarousel({
            loop: false,
            autoplay: false,
            margin: 5,
            nav: false,
            // navText: ["<i class='czi-arrow-left'></i>","<i class='czi-arrow-right'></i>"],
            dots: true,
            autoplayHoverPause: true,
            '<?php echo e(session('direction')); ?>': true,
            // center: true,
            responsive: {
                //X-Small
                0: {
                    items: 2
                },
                360: {
                    items: 3
                },
                375: {
                    items: 3
                },
                540: {
                    items: 4
                },
                //Small
                576: {
                    items: 5
                },
                //Medium
                768: {
                    items: 6
                },
                //Large
                992: {
                    items: 8
                },
                //Extra large
                1200: {
                    items: 10
                },
                //Extra extra large
                1400: {
                    items: 11
                }
            }
        })
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.front-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u690825212/domains/khareedofarokht.pk/public_html/resources/views/web-views/home.blade.php ENDPATH**/ ?>