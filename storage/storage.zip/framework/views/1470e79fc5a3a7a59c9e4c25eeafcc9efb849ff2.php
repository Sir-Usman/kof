<?php $__env->startSection('title',\App\CPU\translate('submit_a_review')); ?>

<?php $__env->startSection('content'); ?>

<!-- Page Content-->
<div class="container pb-5 mb-2 mb-md-4 mt-2 rtl"
     style="text-align: <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>;">
    <div class="row">
        <!-- Sidebar-->
    <?php echo $__env->make('web-views.partials._profile-aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="col-lg-9  col-md-9">
            <div class="card">
                <div class="card-header">
                    <h5 style="margin-left: 20px;"><?php echo e(\App\CPU\translate('submit_a_review')); ?></h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('review.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">

                            <div class="form-group">
                                <label for="exampleInputEmail1"><?php echo e(\App\CPU\translate('rating')); ?></label>
                                <select class="form-control" name="rating">
                                    <option value="1"><?php echo e(\App\CPU\translate('1')); ?></option>
                                    <option value="2"><?php echo e(\App\CPU\translate('2')); ?></option>
                                    <option value="3"><?php echo e(\App\CPU\translate('3')); ?></option>
                                    <option value="4"><?php echo e(\App\CPU\translate('4')); ?></option>
                                    <option value="5"><?php echo e(\App\CPU\translate('5')); ?></option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1"><?php echo e(\App\CPU\translate('comment')); ?></label>
                                <input name="product_id" value="<?php echo e($order_details->product_id); ?>" hidden>
                                <input name="order_id" value="<?php echo e($order_details->order_id); ?>" hidden>
                                <textarea class="form-control" name="comment"></textarea>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1"><?php echo e(\App\CPU\translate('attachment')); ?></label>
                                <div class="row coba"></div>
                                <div class="mt-1 text-info"><?php echo e(\App\CPU\translate('File type: jpg, jpeg, png. Maximum size: 2MB')); ?></div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-secondary"><?php echo e(\App\CPU\translate('back')); ?></a>

                            <button type="submit" class="btn btn--primary"><?php echo e(\App\CPU\translate('submit')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('public/assets/front-end/js/spartan-multi-image-picker.js')); ?>"></script>
    <script type="text/javascript">
        $(function () {
            $(".coba").spartanMultiImagePicker({
                fieldName: 'fileUpload[]',
                maxCount: 5,
                rowHeight: '150px',
                groupClassName: 'col-md-4',
                placeholderImage: {
                    image: '<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>',
                    width: '100%'
                },
                dropFileLabel: "<?php echo e(\App\CPU\translate('drop_here')); ?>",
                onAddRow: function (index, file) {

                },
                onRenderedPreview: function (index) {

                },
                onRemoveRow: function (index) {

                },
                onExtensionErr: function (index, file) {
                    toastr.error('<?php echo e(\App\CPU\translate('input_png_or_jpg')); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                },
                onSizeErr: function (index, file) {
                    toastr.error('<?php echo e(\App\CPU\translate('file_size_too_big')); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/q291duikhtl7/public_html/khareedofarokht.pk/resources/views/web-views/users-profile/submit-review.blade.php ENDPATH**/ ?>