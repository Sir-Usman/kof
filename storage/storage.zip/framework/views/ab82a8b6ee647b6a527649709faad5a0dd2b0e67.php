
<?php $__env->startSection('title', 'Crypto Affiliate'); ?>
<?php $__env->startPush('css_or_js'); ?>
    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('public/assets/back-end')); ?>/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('public/assets/back-end/css/croppie.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
    <!-- Page Title -->
    <div class="mb-3">
        <h2 class="h1 mb-0 d-flex gap-2">
            <img src="<?php echo e(asset('/public/assets/back-end/img/attribute.png')); ?>" alt="">
            <!-- <?php echo e(\App\CPU\translate('Attribute_Setup')); ?> -->
            Crypto Affiliate
        </h2>
    </div>
    <!-- End Page Title -->

    <!-- Content Row -->
    <div class="row">
        <div class="col-md-12 mb-3">
            <div class="card">
                <!-- <div class="card-header">
                    <?php echo e(\App\CPU\translate('Add')); ?> <?php echo e(\App\CPU\translate('new')); ?> <?php echo e(\App\CPU\translate('Attribute')); ?>

                </div> -->
                <div class="card-body" style="text-align: <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>;">
                    <form action="<?php echo e(route('admin.crypto-affiliate.store')); ?>" method="Post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php ($language=\App\Model\BusinessSetting::where('type','pnc_language')->first()); ?>
                        <?php ($language = $language->value ?? null); ?>
                        <?php ($default_lang = 'en'); ?>

                        <?php ($default_lang = json_decode($language)[0]); ?>
                        <ul class="nav nav-tabs w-fit-content mb-4">
                            <?php $__currentLoopData = json_decode($language); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item text-capitalize">
                                    <a class="nav-link lang_link <?php echo e($lang == $default_lang? 'active':''); ?>"
                                        href="#"
                                        id="<?php echo e($lang); ?>-link"><?php echo e(\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                        <div class="form-group <?php echo e($lang != $default_lang ? 'd-none':''); ?> lang_form"
                                    id="<?php echo e($lang); ?>-form">
                            <input type="hidden" id="id">
                            <!-- <label class="title-color" for="name"><?php echo e(\App\CPU\translate('Attribute')); ?> <?php echo e(\App\CPU\translate('Name')); ?><span class="text-danger">*</span>
                                    (<?php echo e(strtoupper($lang)); ?>)</label> -->
                            <!-- <input type="text" name="name[]" class="form-control" id="name"
                                    placeholder="<?php echo e(\App\CPU\translate('Enter_Attribute_Name')); ?>" <?php echo e($lang == $default_lang? 'required':''); ?>> -->
                            <label class="title-color" for="title">Name<span class="text-danger">*</span></label>
                            <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control" id="title"
                                placeholder="Enter Name" required><br>

                            <label class="title-color" for="title">Affiliate Link<span class="text-danger">*</span></label>
                            <input type="text" name="affiliate_link" value="<?php echo e(old('affiliate_link')); ?>" class="form-control" id="title"
                                placeholder="Enter Affiliate Link" required><br>

                            <label class="title-color" for="image">Image<span class="text-danger">*</span></label>
                            <input type="file" name="image" class="form-control" id="image"
                                accept="image/*" required><br>

                            <label class="title-color" >Detail<span class="text-danger">*</span></label>
                            <textarea name="description" id="editor" class="form-control"  
                            placeholder="Enter Description"><?php echo e(old('description')); ?></textarea>
                        </div>
                        <!-- <input type="hidden" name="lang[]" value="<?php echo e($lang); ?>" id="lang"> -->


                        <div class="d-flex flex-wrap gap-2 justify-content-end">
                            <button type="submit" class="btn btn--primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card">
                <div class="px-3 py-4">
                    <div class="row align-items-center">
                            <div class="col-sm-4 col-md-6 col-lg-8 mb-2 mb-sm-0">
                                <h5 class="mb-0 d-flex align-items-center gap-2">Crypto Link List
                                    <span class="badge badge-soft-dark radius-50 fz-12"><?php echo e($crypto_affiliates->total()); ?></span>
                                </h5>
                            </div>
                            <div class="col-sm-8 col-md-6 col-lg-4">
                                <!-- Search -->
                                <form action="<?php echo e(url()->current()); ?>" method="GET">
                                    <div class="input-group input-group-custom input-group-merge">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">
                                                <i class="tio-search"></i>
                                            </div>
                                        </div>
                                        <input id="datatableSearch_" type="search" name="search" class="form-control"
                                            placeholder="Search By Name" aria-label="Search orders" value="<?php echo e($search); ?>" required>
                                        <button type="submit" class="btn btn--primary"><?php echo e(\App\CPU\translate('Search')); ?></button>
                                    </div>
                                </form>
                                <!-- End Search -->
                            </div>
                        </div>
                </div>
                <div style="text-align: <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>;">
                    <div class="table-responsive">
                        <table id="datatable"
                               class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table w-100">
                            <thead class="thead-light thead-50 text-capitalize">
                                <tr>
                                    <th><?php echo e(\App\CPU\translate('SL')); ?></th>
                                    <th>Name </th>
                                    <th class="text-center">Image </th>
                                    <th class="text-center"><?php echo e(\App\CPU\translate('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $crypto_affiliates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$crypto_affiliate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-right"><?php echo e($crypto_affiliates->firstItem()+$key); ?></td>
                                    <td><?php echo e($crypto_affiliate['title']); ?></td>
                                    <td class="text-center">
                                        <img src="<?php echo e($crypto_affiliate['image']); ?>" alt="crypto_affiliate_image" class="img rounded-circle"
                                        width="50px" height="50px">
                                    </td>
                                    <td>
                                       <div class="d-flex justify-content-center gap-2">
                                            <a class="btn btn-outline-info btn-sm square-btn"
                                                title="<?php echo e(\App\CPU\translate('Edit')); ?>"
                                                href="<?php echo e(route('admin.crypto-affiliate.edit',[$crypto_affiliate['id']])); ?>">
                                                <i class="tio-edit"></i>
                                            </a>
                                            <a class="btn btn-outline-danger btn-sm delete square-btn"
                                                title="<?php echo e(\App\CPU\translate('Delete')); ?>"
                                                id="<?php echo e($crypto_affiliate['id']); ?>">
                                                <i class="tio-delete"></i>
                                            </a>
                                       </div> 
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="table-responsive mt-4">
                    <div class="d-flex justify-content-lg-end">
                        <!-- Pagination -->
                        <?php echo $crypto_affiliates->links(); ?>

                    </div>
                </div>

                <?php if(count($crypto_affiliates)==0): ?>
                    <div class="text-center p-4">
                        <img class="mb-3 w-160" src="<?php echo e(asset('public/assets/back-end')); ?>/svg/illustrations/sorry.svg" alt="Image Description">
                        <p class="mb-0"><?php echo e(\App\CPU\translate('No_data_to_show')); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<!-- ck editor -->
<script>
    ClassicEditor
    .create( document.querySelector( '#editor' ) )
        .then( editor => {
            console.log(editor);
        })
    .catch( error => {
        console.error( error );
    } );
</script>
<!-- ck editor -->
<script>
    $(".lang_link").click(function (e) {
        e.preventDefault();
        $(".lang_link").removeClass('active');
        $(".lang_form").addClass('d-none');
        $(this).addClass('active');

        let form_id = this.id;
        let lang = form_id.split("-")[0];
        console.log(lang);
        $("#" + lang + "-form").removeClass('d-none');
        if (lang == '<?php echo e($default_lang); ?>') {
            $(".from_part_2").removeClass('d-none');
        } else {
            $(".from_part_2").addClass('d-none');
        }
    });

    $(document).ready(function () {
        $('#dataTable').DataTable();
    });
</script>
<script>
    $(document).on('click', '.delete', function () {
        var id = $(this).attr("id");
        Swal.fire({
            title: '<?php echo e(\App\CPU\translate('Are_you_sure_to_delete_this')); ?>?',
            text: "<?php echo e(\App\CPU\translate('You_will not_be_able_to_revert_this')); ?>!",
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '<?php echo e(\App\CPU\translate('Yes')); ?>, <?php echo e(\App\CPU\translate('delete_it')); ?>!',
            type: 'warning',
            reverseButtons: true
        }).then((result) => {
            if (result.value) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "<?php echo e(route('admin.crypto-affiliate.delete')); ?>",
                    method: 'POST',
                    data: {id: id},
                    success: function () {
                        toastr.success('<?php echo e(\App\CPU\translate('Crypto Affiliate link deleted successfully')); ?>');
                        location.reload();
                    }
                });
            }
        })
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.back-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/q291duikhtl7/public_html/khareedofarokht.pk/resources/views/admin-views/crypto-affiliate/view.blade.php ENDPATH**/ ?>