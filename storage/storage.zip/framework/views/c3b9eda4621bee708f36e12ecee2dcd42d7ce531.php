<div id="headerMain" class="d-none">
    <header id="header" class="navbar navbar-expand-lg navbar-fixed navbar-height navbar-flush navbar-container navbar-bordered">
        <div class="navbar-nav-wrap">
            <div class="navbar-brand-wrapper">
                <!-- Logo -->
                <?php ($shop=\App\Model\Shop::where(['seller_id'=>auth('seller')->id()])->first()); ?>

                <a class="navbar-brand" href="<?php echo e(route('seller.dashboard.index')); ?>" aria-label="">
                    <?php if(isset($shop)): ?>
                        <img class="navbar-brand-logo"
                             onerror="this.src='<?php echo e(asset('public/assets/back-end/img/160x160/img1.jpg')); ?>'"
                             src="<?php echo e(asset("storage/app/public/shop/$shop->image")); ?>" alt="Logo" height="40">
                        <img class="navbar-brand-logo-mini"
                             onerror="this.src='<?php echo e(asset('public/assets/back-end/img/160x160/img1.jpg')); ?>'"
                             src="<?php echo e(asset("storage/app/public/shop/$shop->image")); ?>"
                             alt="Logo" height="40">

                    <?php else: ?>
                        <img class="navbar-brand-logo-mini"
                             src="<?php echo e(asset('public/assets/back-end/img/160x160/img1.jpg')); ?>"
                             alt="Logo" height="40">
                    <?php endif; ?>

                </a>
                <!-- End Logo -->
            </div>

            <div class="navbar-nav-wrap-content-left">
                <!-- Navbar Vertical Toggle -->
                <button type="button" class="js-navbar-vertical-aside-toggle-invoker close mr-3 d-xl-none">
                    <i class="tio-first-page navbar-vertical-aside-toggle-short-align" data-toggle="tooltip"
                       data-placement="right" title="Collapse"></i>
                    <i class="tio-last-page navbar-vertical-aside-toggle-full-align"
                       data-template='<div class="tooltip d-none d-sm-block" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>'
                       data-toggle="tooltip" data-placement="right" title="Expand"></i>
                </button>
                <!-- End Navbar Vertical Toggle -->

                <div class="d-none">
                    <form class="position-relative">
                    </form>
                </div>
            </div>


            <!-- Secondary Content -->
            <div class="navbar-nav-wrap-content-right"
                 style="<?php echo e(Session::get('direction') === "rtl" ? 'margin-left:unset; margin-right: auto' : 'margin-right:unset; margin-left: auto'); ?>">
                <!-- Navbar -->
                <ul class="navbar-nav align-items-center flex-row">

                    <li class="nav-item d-none d-md-inline-block">
                        <div class="hs-unfold">
                            <div>
                                <?php ( $local = session()->has('local')?session('local'):'en'); ?>
                                <?php ($lang = \App\Model\BusinessSetting::where('type', 'language')->first()); ?>
                                <div
                                    class="topbar-text dropdown disable-autohide <?php echo e(Session::get('direction') === "rtl" ? 'ml-3' : 'm-1'); ?> text-capitalize">
                                    <a class="topbar-link dropdown-toggle d-flex align-items-center title-color" href="#" data-toggle="dropdown"
                                       style="color: black!important;">
                                        <?php $__currentLoopData = json_decode($lang['value'],true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data['code']==$local): ?>
                                                <img class="<?php echo e(Session::get('direction') === "rtl" ? 'ml-2' : 'mr-2'); ?>"
                                                     width="20"
                                                     src="<?php echo e(asset('public/assets/front-end')); ?>/img/flags/<?php echo e($data['code']); ?>.png"
                                                     alt="Eng">
                                                <?php echo e($data['name']); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <?php $__currentLoopData = json_decode($lang['value'],true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data['status']==1): ?>
                                                <li>
                                                    <a class="dropdown-item pb-1"
                                                       href="<?php echo e(route('lang',[$data['code']])); ?>">
                                                        <img
                                                            class="<?php echo e(Session::get('direction') === "rtl" ? 'ml-2' : 'mr-2'); ?>"
                                                            width="20"
                                                            src="<?php echo e(asset('public/assets/front-end')); ?>/img/flags/<?php echo e($data['code']); ?>.png"
                                                            alt="<?php echo e($data['name']); ?>"/>
                                                        <span
                                                            style="text-transform: capitalize"><?php echo e($data['name']); ?></span>
                                                    </a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>

                    <li class="nav-item d-none d-md-inline-block">
                        <!-- Notification -->
                        <div class="hs-unfold">
                            <a title="Website Home"
                               class="js-hs-unfold-invoker btn btn-icon btn-ghost-secondary rounded-circle"
                               href="<?php echo e(route('home')); ?>" target="_blank">
                                <i class="tio-globe"></i>
                                
                            </a>
                        </div>
                        <!-- End Notification -->
                    </li>

                    <li class="nav-item d-none d-md-inline-block">
                        <!-- Notification -->
                        <div class="hs-unfold">
                            <a
                                class="js-hs-unfold-invoker btn btn-icon btn-ghost-secondary rounded-circle media align-items-center gap-3 navbar-dropdown-account-wrapper dropdown-toggle dropdown-toggle-left-arrow" href="javascript:;"
                                data-hs-unfold-options='{
                                     "target": "#messageDropdown",
                                     "type": "css-animation"
                                   }'
                               >
                                <i class="tio-email"></i>
                                <?php ($message=\App\Model\Chatting::where(['seen_by_seller'=>0, 'seller_id'=>auth('seller')->id()])->count()); ?>
                                <?php if($message!=0): ?>
                                    <span class="btn-status btn-sm-status btn-status-danger"><?php echo e($message); ?></span>
                                <?php endif; ?>
                            </a>
                            <div id="messageDropdown"
                                 class="hs-unfold-content dropdown-unfold dropdown-menu dropdown-menu-right navbar-dropdown-menu navbar-dropdown-account"
                                 style="width: 16rem;">

                                <a class="dropdown-item position-relative"
                                   href="<?php echo e(route('seller.messages.chat', ['type' => 'customer'])); ?>">
                                    <span class="text-truncate pr-2"
                                          title="Settings"><?php echo e(\App\CPU\translate('Customer')); ?></span>
                                    <?php ($message_customer=\App\Model\Chatting::where(['seen_by_seller'=>0, 'seller_id'=>auth('seller')->id()])->whereNotNull(['user_id'])->count()); ?>
                                    <?php if($message_customer > 0): ?>
                                        <span class="btn-status btn-sm-status-custom btn-status-danger"><?php echo e($message_customer); ?></span>
                                    <?php endif; ?>


                                </a>

                                <div class="dropdown-divider"></div>

                                <a class="dropdown-item position-relative"
                                   href="<?php echo e(route('seller.messages.chat', ['type' => 'delivery-man'])); ?>">
                                    <span class="text-truncate pr-2"
                                          title="Settings"><?php echo e(\App\CPU\translate('Delivery_man')); ?></span>
                                    <?php ($message_d_man =\App\Model\Chatting::where(['seen_by_seller'=>0, 'seller_id'=>auth('seller')->id()])->whereNotNull(['delivery_man_id'])->count()); ?>
                                    <?php if($message_d_man > 0): ?>
                                        <span class="btn-status btn-sm-status-custom btn-status-danger"><?php echo e($message_d_man); ?></span>
                                    <?php endif; ?>

                                </a>

                            </div>
                        </div>
                        <!-- End Notification -->
                    </li>

                    <li class="nav-item d-none d-md-inline-block">
                        <!-- Notification -->
                        <div class="hs-unfold">
                            <a class="js-hs-unfold-invoker btn btn-icon btn-ghost-secondary rounded-circle"
                               href="<?php echo e(route('seller.orders.list',['pending'])); ?>">
                                <i class="tio-shopping-cart-outlined"></i>
                                <?php ($order=\App\Model\Order::where(['seller_is'=>'seller','seller_id'=>auth('seller')->id(), 'order_status'=>'pending'])->count()); ?>
                                <?php if($order!=0): ?>
                                <span class="btn-status btn-sm-status btn-status-danger"><?php echo e($order); ?></span>
                               <?php endif; ?>
                            </a>
                        </div>
                        <!-- End Notification -->
                    </li>

                    <li class="nav-item view-web-site-info">
                        <div class="hs-unfold">
                            <a style="background-color: rgb(255, 255, 255)" onclick="openInfoWeb()" href="javascript:"
                               class="js-hs-unfold-invoker btn btn-icon btn-ghost-secondary rounded-circle">
                                <i class="tio-info"></i>
                            </a>
                        </div>
                    </li>

                    <!-- <li class="nav-item view-web-site-info">
                        <div class="hs-unfold" >
                            <a onclick="openInfoWeb()" href="javascript:" class="bg-white js-hs-unfold-invoker btn btn-icon btn-ghost-secondary rounded-circle">
                                <i class="tio-info"></i>
                            </a>
                        </div>
                    </li> -->

                    <li class="nav-item">
                        <!-- Account -->
                        <div class="hs-unfold">
                            <a class="js-hs-unfold-invoker media align-items-center gap-3 navbar-dropdown-account-wrapper dropdown-toggle dropdown-toggle-left-arrow" href="javascript:;"
                               data-hs-unfold-options='{
                                     "target": "#accountNavbarDropdown",
                                     "type": "css-animation"
                                   }'>
                                <div class="d-none d-md-block media-body text-right">
                                  <h5 class="profile-name mb-0"><?php echo e(auth('seller')->user()->name); ?></h5> 
                                  
                                </div>
                                <div class="avatar avatar-sm avatar-circle">
                                    <img class="avatar-img"
                                         onerror="this.src='<?php echo e(asset('public/assets/back-end/img/160x160/img1.jpg')); ?>'"
                                         src="<?php echo e(asset('storage/app/public/seller/')); ?>/<?php echo e(auth('seller')->user()->image); ?>"
                                         alt="Image Description">
                                    <span class="avatar-status avatar-sm-status avatar-status-success"></span>
                                </div>
                            </a>

                            <div id="accountNavbarDropdown"
                                 class="hs-unfold-content dropdown-unfold dropdown-menu dropdown-menu-right navbar-dropdown-menu navbar-dropdown-account"
                                 style="width: 16rem;">
                                <div class="dropdown-item-text">
                                    <div class="media align-items-center text-break">
                                        <div class="avatar avatar-sm avatar-circle mr-2">

                                            <img class="avatar-img"
                                                 onerror="this.src='<?php echo e(asset('public/assets/back-end/img/160x160/img1.jpg')); ?>'"
                                                 src="<?php echo e(asset('storage/app/public/seller/')); ?>/<?php echo e(auth('seller')->user()->image); ?>"
                                                 alt="Image Description">
                                        </div>
                                        <div class="media-body">
                                            <span class="card-title h5"><?php echo e(auth('seller')->user()->f_name); ?></span>

                                            <span class="card-text"><?php echo e(auth('seller')->user()->email); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="dropdown-divider"></div>

                                <a class="dropdown-item"
                                   href="<?php echo e(route('seller.profile.update',auth('seller')->user()->id)); ?>">
                                    <span class="text-truncate pr-2"
                                          title="Settings"><?php echo e(\App\CPU\translate('Settings')); ?></span>
                                </a>

                                <div class="dropdown-divider"></div>

                                <a class="dropdown-item" href="javascript:" onclick="Swal.fire({
                                    title: '<?php echo e(\App\CPU\translate('Do you want to logout')); ?>?',
                                    showDenyButton: true,
                                    showCancelButton: true,
                                    confirmButtonColor: '#377dff',
                                    cancelButtonColor: '#363636',
                                    confirmButtonText: `Yes`,
                                    denyButtonText: `Don't Logout`,
                                    }).then((result) => {
                                    if (result.value) {
                                    location.href='<?php echo e(route('seller.auth.logout')); ?>';
                                    } else{
                                    Swal.fire('Canceled', '', 'info')
                                    }
                                    })">
                                    <span class="text-truncate pr-2"
                                          title="Sign out"><?php echo e(\App\CPU\translate('Sign out')); ?></span>
                                </a>
                            </div>
                        </div>
                        <!-- End Account -->
                    </li>
                </ul>
                <!-- End Navbar -->
            </div>
            <!-- End Secondary Content -->
        </div>
        <div id="website_info"
             style="display:none;" class="bg-secondary w-100">
            <div class="p-3">
                <div class="bg-white p-1 rounded">
                    <?php ( $local = session()->has('local')?session('local'):'en'); ?>
                    <?php ($lang = \App\Model\BusinessSetting::where('type', 'language')->first()); ?>
                    <div
                        class="topbar-text dropdown disable-autohide <?php echo e(Session::get('direction') === "rtl" ? 'ml-3' : 'm-1'); ?> text-capitalize">
                        <a class="topbar-link dropdown-toggle title-color d-flex align-items-center" href="#" data-toggle="dropdown">
                            <?php $__currentLoopData = json_decode($lang['value'],true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($data['code']==$local): ?>
                                    <img class="<?php echo e(Session::get('direction') === "rtl" ? 'ml-2' : 'mr-2'); ?>"
                                         width="20"
                                         src="<?php echo e(asset('public/assets/front-end')); ?>/img/flags/<?php echo e($data['code']); ?>.png"
                                         alt="Eng">
                                    <?php echo e($data['name']); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <?php $__currentLoopData = json_decode($lang['value'],true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($data['status']==1): ?>
                                    <li>
                                        <a class="dropdown-item pb-1"
                                           href="<?php echo e(route('lang',[$data['code']])); ?>">
                                            <img
                                                class="<?php echo e(Session::get('direction') === "rtl" ? 'ml-2' : 'mr-2'); ?>"
                                                width="20"
                                                src="<?php echo e(asset('public/assets/front-end')); ?>/img/flags/<?php echo e($data['code']); ?>.png"
                                                alt="<?php echo e($data['name']); ?>"/>
                                            <span style="text-transform: capitalize"><?php echo e($data['name']); ?></span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="bg-white p-1 rounded mt-2">
                    <a title="Website home" class="p-2 title-color"
                       href="<?php echo e(route('home')); ?>" target="_blank">
                        <i class="tio-globe"></i>

                        <?php echo e(\App\CPU\translate('view_website')); ?>

                    </a>
                </div>
                <div class="bg-white p-1 rounded mt-2">
                    <a class="p-2  title-color"
                       href="<?php echo e(route('seller.messages.chat', ['type' => 'customer'])); ?>">
                        <i class="tio-email"></i>
                        <?php echo e(\App\CPU\translate('message')); ?>

                        <?php ($message=\App\Model\Chatting::where(['seen_by_seller'=>1,'seller_id'=>auth('seller')->id()])->count()); ?>
                        <?php if($message!=0): ?>
                            <span class="">(<?php echo e($message); ?>)</span>
                        <?php endif; ?>
                    </a>
                </div>
                <div class="bg-white p-1 rounded mt-2">
                    <a class="p-2 title-color"
                       href="<?php echo e(route('seller.orders.list',['pending'])); ?>">
                        <i class="tio-shopping-cart-outlined"></i>
                        <?php echo e(\App\CPU\translate('Order_list')); ?>

                    </a>
                </div>

            </div>
        </div>
    </header>
</div>
<div id="headerFluid" class="d-none"></div>
<div id="headerDouble" class="d-none"></div>
<?php /**PATH /home/u690825212/domains/khareedofarokht.pk/public_html/resources/views/layouts/back-end/partials-seller/_header.blade.php ENDPATH**/ ?>