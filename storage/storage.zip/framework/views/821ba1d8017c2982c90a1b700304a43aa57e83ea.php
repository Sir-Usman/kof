

<?php $__env->startSection('title','Blogs'); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta property="og:image" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="og:title" content="Brands of <?php echo e($web_config['name']->value); ?> "/>
    <meta property="og:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="og:description" content="<?php echo substr($web_config['about']->value,0,100); ?>">

    <meta property="twitter:card" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="twitter:title" content="Brands of <?php echo e($web_config['name']->value); ?>"/>
    <meta property="twitter:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="twitter:description" content="<?php echo substr($web_config['about']->value,0,100); ?>">
    <style>
        .page-item.active .page-link {
            background-color: <?php echo e($web_config['primary_color']); ?>    !important;
        }

        .page-item.active > .page-link {
            box-shadow: 0 0 black !important;
        }

        .person:hover{
            color: #B38A11 !important;
        }
        .person{
            transition: 0.2s ease-in;
        }
        .person span{
            font-size:13px;
            font-weight:bold;
        }
        .blog_main p{
            color:gray;
        }
        .blog_main p:hover{
            color: #B38A11 !important;
        }
        
        
        .blog-card{
            overflow: hidden;
        }
        .blog-card img{
        }
        .blog-card:hover img {
            transform: scale(1.1);
            transition: 1s ease-in-out;
            border-radius: 10px;

        }

       

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Content-->
    <div class="container mb-md-4">
        <div class="row mt-3 mb-3 border-bottom">
            <div class="col-md-8">
                <h4 class="mt-2">Blogs</h4>
            </div>
            <div class="col-md-4">
                <form action="<?php echo e(route('search-shop')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control"  placeholder="<?php echo e(\App\CPU\translate('Shop name')); ?>" name="shop_name" required>
                        <div class="input-group-append">
                            <button class="btn btn-outline-secondary" type="submit"><?php echo e(\App\CPU\translate('Search')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Products grid-->
        <div class="row">
            <div class="col-lg-9">
                <div class="row blog_main">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('blog.single',[$blog['id']])); ?>">
                        <div class="col-lg-4 mb-3 blog-card">
                            <img src="<?php echo e($blog->image); ?>" alt="blog_image" style="width: 100%; height: 195px;" class="img-fluid">
                            <div class="mt-3">
                                <small>Posted in 
                                    <span class="fw-bold text-dark px-1">
                                        <?php echo e($blog->created_at->format('d-m-Y')); ?>

                                    </span> 
                                </small>
                                <h5><a href="#" class="text-decoration-none text-dark mt-4"> <b><?php echo e($blog->title); ?></b></a></h5>
                                <p>
                                
                                </p>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- sidebar -->
            <div class="col-lg-3 d-lg-block d-none">
                <div class="row">
                    <div class="review  bg-body rounded px-3">
                        <h6 class="mb-3 mt-1 text-warning text-bold">Popular Blogs</h6>
                        <?php $__currentLoopData = $sidebar_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('blog.single', [$blog['id']])); ?>">
                            <div class="person shadow d-flex align-items-center mb-4">
                                <img src="<?php echo e($blog->image); ?>" alt="blog_image" style="width: 65px; height: 65px;">

                                <div class="mt-1 pl-3">
                                    <p class="lh-base mb-1"><?php echo e($blog->title); ?></p>
                                    <span class="fw-bold" ><?php echo e($blog->created_at->format('d-m-Y')); ?></span>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <!-- end sidebar -->
        </div>

        <div class="row ">
            <div class="col-md-12">
                <?php echo e($blogs->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u690825212/domains/khareedofarokht.pk/public_html/resources/views/web-views/blog/view.blade.php ENDPATH**/ ?>