<div class="inline-page-menu my-4">
    <ul class="list-unstyled">
        <li class="<?php echo e(Request::is('admin/business-settings/terms-condition') ?'active':''); ?>"><a href="<?php echo e(route('admin.business-settings.terms-condition')); ?>"><?php echo e(\App\CPU\translate('Terms_&_Conditions')); ?></a></li>
        <li class="<?php echo e(Request::is('admin/business-settings/privacy-policy') ?'active':''); ?>"><a href="<?php echo e(route('admin.business-settings.privacy-policy')); ?>"><?php echo e(\App\CPU\translate('Privacy_Policy')); ?></a></li>
        <li class="<?php echo e(Request::is('admin/business-settings/about-us') ?'active':''); ?>"><a href="<?php echo e(route('admin.business-settings.about-us')); ?>"><?php echo e(\App\CPU\translate('About_Us')); ?></a></li>
        <li class="<?php echo e(Request::is('admin/helpTopic/list') ?'active':''); ?>"><a href="<?php echo e(route('admin.helpTopic.list')); ?>"><?php echo e(\App\CPU\translate('FAQ')); ?></a></li>
    </ul>
</div>
<?php /**PATH /home/q291duikhtl7/public_html/khareedofarokht.pk/resources/views/admin-views/business-settings/pages-inline-menu.blade.php ENDPATH**/ ?>