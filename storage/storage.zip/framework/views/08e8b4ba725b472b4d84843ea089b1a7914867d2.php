

<?php $__env->startSection('title','Buy Crypto Currencies'); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta property="og:image" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="og:title" content="Brands of <?php echo e($web_config['name']->value); ?> "/>
    <meta property="og:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="og:description" content="<?php echo substr($web_config['about']->value,0,100); ?>">

    <meta property="twitter:card" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="twitter:title" content="Brands of <?php echo e($web_config['name']->value); ?>"/>
    <meta property="twitter:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="twitter:description" content="<?php echo substr($web_config['about']->value,0,100); ?>">
    <style>
        .page-item.active .page-link {
            background-color: <?php echo e($web_config['primary_color']); ?>    !important;
        }

        .page-item.active > .page-link {
            box-shadow: 0 0 black !important;
        }

        .crypto-card{
            border-radius: 10px;
            border-width: 3px !important;
            border-color: #B38A11 !important;
        }
        .crypto-card img {
            border: 3px solid transparent !important;
            border-radius: 10px;
        }
        .crypto-card:hover img {
            transform: scale(1.15);
            transition: 1s ease-in-out;
            border: 3px solid green !important;
            border-radius: 10px;
        }
        .crypto-card:hover{
            border-color: #B38A11 !important;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Page Content-->
    <div class="container mb-md-4">
        <div class="row mt-3 mb-3 border-bottom">
            <div class="col-md-12">
                <h4 class="mt-2">Crypto Currency</h4>
            </div>
        </div>
        <!-- Products grid-->
        <div class="row ">
            <div class="col-lg-12">
                <div class="row">
                    <?php $__currentLoopData = $crypto_affiliates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crypto_affiliate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('crypto-affiliates.show',[$crypto_affiliate['id']])); ?>">
                        <div class="col-sm-6 col-md-4 col-lg-3 mb-3" data-aos="fade-up">
                            <div class="border crypto-card p-2">
                                <img src="<?php echo e($crypto_affiliate->image); ?>" alt="blog_image" style="width: 100%; height: 195px;" class="img-fluid">
                                <div class="mt-3">
                                    <h5 style="overflow:hidden; height:47px;"><a href="#" class="text-decoration-none text-dark mt-4"> <b><?php echo e($crypto_affiliate->title); ?></b></a></h5>
                                    <div style="overflow:hidden; height:67px;"> <?php echo \Illuminate\Support\Str::limit($crypto_affiliate->description, 120, $end='...'); ?></div>
                                </div>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- sidebar -->
            
            <!-- end sidebar -->
        </div>

        <div class="row ">
            <div class="col-md-12">
                <?php echo e($crypto_affiliates->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u690825212/domains/khareedofarokht.pk/public_html/resources/views/web-views/crypto-affiliate/view.blade.php ENDPATH**/ ?>