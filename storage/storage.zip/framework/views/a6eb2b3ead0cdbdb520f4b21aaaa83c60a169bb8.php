<style>
    body {
        font-family: sans-serif;
    }

    .footer span {
        font-size: 12px
    }

    .product-qty span {
        font-size: 12px;
        color: #6A6A6A;
    }

    label {
        font-size: 16px;
    }

    .divider-role {
        border-bottom: 1px solid whitesmoke;
    }

    .sidebarL h3:hover + .divider-role {
        border-bottom: 3px solid <?php echo e($web_config['secondary_color']); ?>    !important;
        transition: .2s ease-in-out;
    }

    .price_sidebar {
        padding: 20px;
    }

    @media (max-width: 600px) {

        .sidebar_heading h1 {
            text-align: center;
            color: aliceblue;
            padding-bottom: 17px;
            font-size: 19px;
        }

        .sidebarR {
            padding: 24px;
        }

        .price_sidebar {
            padding: 20px;
        }
    }

</style>

<div class="sidebarR col-lg-3 col-md-3">
    <!--Price Sidebar-->
    <div class="price_sidebar rounded-lg box-shadow-sm" id="shop-sidebar" style="margin-bottom: -10px;background: white">
        <div class="box-shadow-sm">

        </div>
        <div class="pb-0" style="padding-top: 12px;">
            <!-- Filter by price-->
            <div class="sidebarL">
                <h3 class="widget-title btnF" style="font-weight: 700;">
                    <a class="<?php echo e(Request::is('account-oder*') || Request::is('account-order-details*') ? 'active-menu' :''); ?>" href="<?php echo e(route('account-oder')); ?> "><?php echo e(\App\CPU\translate('my_order')); ?></a>
                </h3>
                <div class="divider-role"
                     style="border: 1px solid whitesmoke; margin-bottom: 14px;  margin-top: -6px;">
                </div>
            </div>
        </div>
        <?php
            $wallet_status = App\CPU\Helpers::get_business_settings('wallet_status');
            $loyalty_point_status = App\CPU\Helpers::get_business_settings('loyalty_point_status');
        ?>
        <?php if($wallet_status == 1): ?>
            <div class="pb-0">
                <!-- Filter by price-->
                <div class="sidebarL">
                    <h3 class="widget-title btnF" style="font-weight: 700;">
                        <a class="<?php echo e(Request::is('wallet')?'active-menu':''); ?>" href="<?php echo e(route('wallet')); ?> "><?php echo e(\App\CPU\translate('my_wallet')); ?> </a>
                    </h3>
                    <div class="divider-role"
                        style="border: 1px solid whitesmoke; margin-bottom: 14px;  margin-top: -6px;">
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if($loyalty_point_status == 1): ?>
            <div class="pb-0">
                <!-- Filter by price-->
                <div class="sidebarL">
                    <h3 class="widget-title btnF" style="font-weight: 700;">
                        <a class="<?php echo e(Request::is('loyalty')?'active-menu':''); ?>" href="<?php echo e(route('loyalty')); ?> "><?php echo e(\App\CPU\translate('my_loyalty_point')); ?></a>
                    </h3>
                    <div class="divider-role"
                        style="border: 1px solid whitesmoke; margin-bottom: 14px;  margin-top: -6px;">
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="pb-0">
            <!-- Filter by price-->
            <div class="sidebarL">
                <h3 class="widget-title btnF" style="font-weight: 700;">
                    <a class="<?php echo e(Request::is('track-order*')?'active-menu':''); ?>" href="<?php echo e(route('track-order.index')); ?> "><?php echo e(\App\CPU\translate('track_your_order')); ?></a>
                </h3>
                <div class="divider-role"
                     style="border: 1px solid whitesmoke; margin-bottom: 14px;  margin-top: -6px;">
                </div>
            </div>
        </div>
        <div class="pb-0">
            <!-- Filter by price-->
            <div class="sidebarL">
                <h3 class="widget-title btnF " style="font-weight: 700;">
                    <a class="<?php echo e(Request::is('wishlists*')?'active-menu':''); ?>" href="<?php echo e(route('wishlists')); ?>"> <?php echo e(\App\CPU\translate('wish_list')); ?>  </a></h3>
                <div class="divider-role"
                     style="border: 1px solid whitesmoke; margin-bottom: 14px;  margin-top: -6px;">
                </div>
            </div>
        </div>

        
        <?php ($business_mode=\App\CPU\Helpers::get_business_settings('business_mode')); ?>
        <?php if($business_mode == 'multi'): ?>
            <div class="pb-0">
                <!-- Filter by price-->
                <div class="sidebarL">
                    <h3 class="widget-title btnF" style="font-weight: 700;">
                        <a class="<?php echo e(Request::is('chat/seller')?'active-menu':''); ?>" href="<?php echo e(route('chat', ['type' => 'seller'])); ?>"><?php echo e(\App\CPU\translate('chat_with_seller')); ?></a>
                    </h3>
                    <div class="divider-role"
                        style="border: 1px solid whitesmoke; margin-bottom: 14px;  margin-top: -6px;">
                    </div>
                </div>
            </div>
            <div class="pb-0">
                <div class="sidebarL">
                    <h3 class="widget-title btnF" style="font-weight: 700;">
                        <a class="<?php echo e(Request::is('chat/delivery-man')?'active-menu':''); ?>" href="<?php echo e(route('chat', ['type' => 'delivery-man'])); ?>"><?php echo e(\App\CPU\translate('chat_with_delivery-man')); ?></a>
                    </h3>
                    <div class="divider-role"
                        style="border: 1px solid whitesmoke; margin-bottom: 14px;  margin-top: -6px;">
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="pb-0">
            <!-- Filter by price-->
            <div class=" sidebarL">
                <h3 class="widget-title btnF" style="font-weight: 700;">
                    <a class="<?php echo e(Request::is('user-account*')?'active-menu':''); ?>" href="<?php echo e(route('user-account')); ?>">
                        <?php echo e(\App\CPU\translate('profile_info')); ?>

                    </a>
                </h3>
                <div class="divider-role"
                     style="border: 1px solid whitesmoke; margin-bottom: 14px;  margin-top: -6px;">
                </div>
            </div>
        </div>
        <div class="pb-0">
            <!-- Filter by price-->
            <div class=" sidebarL">
                <h3 class="widget-title btnF" style="font-weight: 700;">
                    <a class="<?php echo e(Request::is('account-address*')?'active-menu':''); ?>"
                       href="<?php echo e(route('account-address')); ?>"><?php echo e(\App\CPU\translate('address')); ?> </a>
                </h3>
                <div class="divider-role"
                     style="border: 1px solid whitesmoke; margin-bottom: 14px;  margin-top: -6px;">
                </div>
            </div>
        </div>
        <div class="pb-0">
            <!-- Filter by price-->
            <div class=" sidebarL">
                <h3 class="widget-title btnF" style="font-weight: 700;">
                    <a class="<?php echo e((Request::is('account-ticket*') || Request::is('support-ticket*'))?'active-menu':''); ?>"
                       href="<?php echo e(route('account-tickets')); ?>"><?php echo e(\App\CPU\translate('support_ticket')); ?></a></h3>
                <div class="divider-role"
                     style="border: 1px solid whitesmoke; margin-bottom: 14px;  margin-top: -6px;">
                </div>
            </div>
        </div>

    </div>
</div>


















<?php /**PATH /home/q291duikhtl7/public_html/khareedofarokht.pk/resources/views/web-views/partials/_profile-aside.blade.php ENDPATH**/ ?>